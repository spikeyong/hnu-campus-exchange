@echo off
rem Print every address that currently works.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0show-url.ps1" %*
pause
