@echo off
rem Stop the public tunnel.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-tunnel.ps1" %*
if errorlevel 1 pause
