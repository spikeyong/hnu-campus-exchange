@echo off
rem Runs at logon (placed in the Startup folder) to bring the site + tunnel back.
setlocal
cd /d "%~dp0"

rem give the desktop and network a moment after logon
timeout /t 10 /nobreak >nul

powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0start-site.ps1"
timeout /t 3 /nobreak >nul
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0start-tunnel.ps1"
