# Stop the Haida Mutual-Aid site.
# Ends the scheduled task, then kills whatever still listens on the port.
# Usage:  powershell -ExecutionPolicy Bypass -File .\stop-site.ps1 [-Port 8080]

param([int]$Port = 8080)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$dataDir = Join-Path $root 'data'
$taskName = 'HaidaCampusSite'
$stopped = 0

& schtasks /end /tn $taskName *> $null
if ($LASTEXITCODE -eq 0) { $stopped++ }

$pidFile = Join-Path $dataDir 'site.pid'
if (Test-Path $pidFile) {
    $recorded = (Get-Content -Path $pidFile | Select-Object -First 1)
    if ($recorded) {
        & taskkill /PID $recorded /T /F *> $null
        if ($LASTEXITCODE -eq 0) { $stopped++ }
    }
    Remove-Item -Path $pidFile -Force
}

$matches = netstat -ano | Select-String -Pattern ":$Port\s+\S+\s+LISTENING"
foreach ($line in $matches) {
    $parts = ($line.ToString().Trim() -split '\s+')
    $listener = $parts[-1]
    if ($listener -match '^\d+$') {
        & taskkill /PID $listener /T /F *> $null
        if ($LASTEXITCODE -eq 0) { $stopped++ }
    }
}

Start-Sleep -Milliseconds 500
$stillUp = $false
try {
    $stillUp = (Invoke-WebRequest -Uri "http://127.0.0.1:$Port/health" -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200
} catch {
    $stillUp = $false
}

if ($stillUp) {
    Write-Host "Something is still answering on port $Port."
    exit 1
}

Write-Host "Site stopped (port $Port is free)."
