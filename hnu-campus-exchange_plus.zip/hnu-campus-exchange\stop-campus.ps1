﻿# =====================================================================
#  停止 start-campus.ps1 启动的后端 / 前端进程
#  用法：powershell -ExecutionPolicy Bypass -File .\stop-campus.ps1
# =====================================================================
[CmdletBinding()]
param(
    [int]$BackendPort = 8000,
    [int]$FrontendPort = 5173
)

$root = $PSScriptRoot
$pidFile = Join-Path $root '.logs\pids.json'

function Stop-Tree([int]$procId) {
    $children = Get-CimInstance Win32_Process -Filter "ParentProcessId=$procId" -ErrorAction SilentlyContinue
    foreach ($c in $children) { Stop-Tree ([int]$c.ProcessId) }
    Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
}

$stopped = @()

if (Test-Path $pidFile) {
    try {
        $pids = Get-Content $pidFile -Raw | ConvertFrom-Json
        foreach ($p in @($pids.backend, $pids.frontend)) {
            if ($p -and (Get-Process -Id $p -ErrorAction SilentlyContinue)) {
                Stop-Tree ([int]$p)
                $stopped += $p
            }
        }
    } catch { }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

# 兜底：按端口清理
foreach ($port in @($BackendPort, $FrontendPort)) {
    $conns = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    foreach ($c in $conns) {
        $ownerPid = [int]$c.OwningProcess
        if ($ownerPid -and (Get-Process -Id $ownerPid -ErrorAction SilentlyContinue)) {
            Stop-Tree $ownerPid
            $stopped += $ownerPid
        }
    }
}

if ($stopped.Count -gt 0) {
    Write-Host ("[已停止] 进程 " + (($stopped | Select-Object -Unique) -join ', ')) -ForegroundColor Green
} else {
    Write-Host '[提示] 没有发现正在运行的后端 / 前端进程。' -ForegroundColor Yellow
}
