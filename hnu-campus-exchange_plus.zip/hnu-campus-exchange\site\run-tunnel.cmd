@echo off
rem Quick Cloudflare tunnel to the local site. Started by start-tunnel.ps1.
setlocal
cd /d "%~dp0"
if not exist "%~dp0data\logs" mkdir "%~dp0data\logs"
if not exist "%~dp0tools\cloudflared.exe" (
    echo cloudflared.exe not found in tools\ 1>&2
    exit /b 1
)
"%~dp0tools\cloudflared.exe" tunnel --url http://127.0.0.1:8080 --no-autoupdate >> "%~dp0data\logs\tunnel.log" 2>&1
