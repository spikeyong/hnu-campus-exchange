@echo off
rem Start the public Cloudflare tunnel and print the https address.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-tunnel.ps1" %*
if errorlevel 1 pause
