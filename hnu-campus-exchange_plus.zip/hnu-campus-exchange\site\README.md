# 一体化网站模式（site/）

把项目跑成**一个**网站进程：FastAPI 同时提供 `/api/v1` 和前端页面。
前端产物由后端直接托管，同源 —— 不需要 nginx、不需要 CORS、不需要跨端口代理。

```
浏览器 ──> http://127.0.0.1:8080 ──> FastAPI（1 个进程）
                                    ├─ /            → dist/（vite build 产物）
                                    ├─ /assets/*    → dist/assets
                                    ├─ /uploads/*   → 上传文件
                                    └─ /api/v1/*    → backend/app 的接口
```

原项目的 `backend/`、`frontend/` **一行不改**，`site/` 只是一个运行外壳。

## 前置条件

| 需要 | 说明 |
|---|---|
| Python 3.12+ | 装依赖：`python -m pip install -r backend/requirements.txt` |
| Node.js 18+ | 构建前端：进 `frontend/` 跑 `npm install`（只需一次） |
| cloudflared（可选） | 想要公网地址时才要，见下文 |

## 三步跑起来

```powershell
cd site

# 1. 构建前端产物到 site\dist（只需在改了前端代码后重跑）
powershell -ExecutionPolicy Bypass -File .\rebuild-frontend.ps1

# 2. 起站点（双击 start-site.cmd 等价）
start-site.cmd

# 3. 浏览器打开 http://127.0.0.1:8080/
```

首次启动会自动建库、建管理员、写分类，数据落在 `site\data\campus_exchange.db`。

## 命令一览

| 命令 | 作用 |
|---|---|
| `start-site.cmd` | 起站点；默认绑 `0.0.0.0:8080`，会打印本机 / 局域网地址 |
| `stop-site.cmd` | 停站点（计划任务 → pid → 端口 三重兜底） |
| `show-url.cmd` | 打印当前所有可用地址（本机 / 局域网 / 公网） |
| `start-tunnel.cmd` | 起 Cloudflare 快速隧道，打印一个 https 公网地址 |
| `stop-tunnel.cmd` | 停隧道 |
| `rebuild-frontend.ps1` | 重新构建 `site\dist` |

同名 `.ps1` 是 `.cmd` 内部调用的脚本，**不要直接双击 `.ps1`**（Windows 默认用记事本打开）。

参数：

```powershell
.\start-site.ps1 -Port 8081          # 换端口
.\start-site.ps1 -Bind 127.0.0.1     # 只允许本机访问
```

## 公网访问（不需要服务器、不需要备案）

用 Cloudflare 的快速隧道，把本机 8080 映射成 `https://xxx-yyy-zzz.trycloudflare.com`：

1. 下载 `cloudflared-windows-amd64.exe`，重命名为 `cloudflared.exe`，放进 `site\tools\`；
   下载页：<https://github.com/cloudflare/cloudflared/releases/latest>
2. `start-tunnel.cmd` → 打印 `Public URL: https://...`
3. `stop-tunnel.cmd` 关闭

注意：

- 隧道随时可能断，**每次重启 URL 都会变**；
- 官方明确说明无账号的快速隧道**没有可用性保证**，仅适合临时演示；
- 链接是公开的，谁拿到都能访问；同时 `APP_ENV=development` 会把短信验证码直接返回给前端，**只适合给同学/老师看一眼，不要放真实个人信息**；
- 这台电脑必须开着，隧道只是端口映射，不是云托管。

要固定地址，用 Cloudflare 命名隧道（需要账号 + 域名）、cpolar，或直接 `docker compose` 部署到服务器。

## 数据与重置

| 路径 | 内容 |
|---|---|
| `data\campus_exchange.db` | SQLite 数据（演示账号、发布、交易） |
| `data\uploads\` | 上传的图片与认证材料 |
| `data\logs\site.log` | 站点日志 |
| `data\logs\tunnel.log` | 隧道日志 |
| `dist\` | 前端构建产物 |

想回到空库：`stop-site.cmd` → 删掉 `data\campus_exchange.db` → 重新 `start-site.cmd`。
空库首次启动会写入管理员 `admin / Admin123!`（仅开发环境）和 6 个默认分类。

## 两个必须知道的约束

1. **`SECRET_KEY` 不能随便换。** 手机号的 `blind_index`（HMAC）、认证材料的 AES-GCM 密文都由它派生，换 key 后已有账号会"查不到"，加密字段也解不开。默认沿用开发值 `development-only-change-me`；要换请同时重建数据。
2. **`APP_ENV` 必须是 `development`。** `backend/app/services/sms.py` 在 `production` 下会直接抛 503，短信登录会挂。真要做生产站，请按根目录 `README.md` 的 Docker 方案配合真实短信服务。

## 故障排查

| 现象 | 处理 |
|---|---|
| 打不开 | 先看 <http://127.0.0.1:8080/health>；没起就 `start-site.cmd` |
| `dist/ is missing` | 先跑 `rebuild-frontend.ps1`（需要 `frontend/node_modules`） |
| 打开是"无法访问此网站" | 用 `127.0.0.1` 而不是 `localhost`（后者可能解析到 IPv6 的 `::1`） |
| 公网地址 502 | 站点没起，或隧道断了 → 重跑 `start-tunnel.cmd`（会换新地址） |
| 页面白屏 | F12 看 Console + `data\logs\site.log` 末尾 |
| 端口被占用 | `start-site.ps1 -Port 8081` |
| 登录提示"该手机号尚未注册" | 库里没有该号，先注册，或换一个手机号 |
| 验证码提示"请在 xx 秒后重试" | 同一号码 60 秒限流，等一会儿 |

整站自检（九项：首页、健康检查、列表、分类、短信登录、/me、交易、管理员登录）：

```powershell
python verify_site.py
```
