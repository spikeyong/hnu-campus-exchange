@echo off
rem Double-click friendly wrapper around start-site.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-site.ps1" %*
if errorlevel 1 pause
