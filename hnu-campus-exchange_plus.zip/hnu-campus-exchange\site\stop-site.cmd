@echo off
rem Stop the site (works from cmd.exe and by double-click).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-site.ps1" %*
if errorlevel 1 pause
