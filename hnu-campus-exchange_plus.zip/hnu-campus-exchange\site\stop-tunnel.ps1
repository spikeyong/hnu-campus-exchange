# Stop the temporary public tunnel started by .\start-tunnel.ps1

$ErrorActionPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$taskName = 'HaidaCampusTunnel'

& schtasks /end /tn $taskName *> $null
$taskEnded = ($LASTEXITCODE -eq 0)

$killed = 0
Get-Process cloudflared -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.Id -Force
    $killed++
}

# the cmd wrapper may still linger
Get-CimInstance Win32_Process -Filter "Name = 'cmd.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like '*run-tunnel*' } |
    ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
        $killed++
    }

if ($taskEnded -or $killed -gt 0) {
    Write-Host "Tunnel stopped (task ended: $taskEnded, processes killed: $killed)."
} else {
    Write-Host 'No tunnel was running.'
}
