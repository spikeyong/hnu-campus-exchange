﻿# =====================================================================
#  海南大学校园资源交换与技能互助平台 —— 一键启动
#  用法（在本目录打开 PowerShell）：
#      powershell -ExecutionPolicy Bypass -File .\start-campus.ps1
#  或右键脚本 -> “使用 PowerShell 运行”
#
#  首次运行会自动做一次性安装（.venv 依赖 / 前端 node_modules），
#  之后每次启动约 5 秒。关闭服务请运行 .\stop-campus.ps1
# =====================================================================
[CmdletBinding()]
param(
    [int]$BackendPort = 8000,
    [int]$FrontendPort = 5173,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
Set-Location $root

$logDir = Join-Path $root '.logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

function Step([string]$m) { Write-Host ("[启动] " + $m) -ForegroundColor Cyan }
function Warn2([string]$m) { Write-Host ("[提示] " + $m) -ForegroundColor Yellow }
function Die([string]$m) { Write-Host ("[失败] " + $m) -ForegroundColor Red; exit 1 }

function Test-PortBusy([int]$port) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    return [bool]$conn
}

function Wait-Http([string]$url, [int]$seconds = 90) {
    $deadline = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 3
            if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 700
    }
    return $false
}

# ---------- 1. Python 解释器 ----------
$python = Join-Path $root '.venv\Scripts\python.exe'
$needDeps = $false
if (-not (Test-Path $python)) {
    Step '未找到 .venv，正在创建 Python 虚拟环境（一次性）'
    $base = $null
    if (Get-Command py -ErrorAction SilentlyContinue) {
        foreach ($v in @('-3.12', '-3.11', '-3.13', '-3.10')) {
            try { & py $v -c "import sys" 2>$null; if ($LASTEXITCODE -eq 0) { $base = @('py', $v); break } } catch { }
        }
    }
    if (-not $base -and (Get-Command python -ErrorAction SilentlyContinue)) { $base = @('python') }
    if (-not $base) { Die '本机没有可用的 Python，请先安装 Python 3.12（勾选 Add to PATH）后重试。' }

    & $base[0] $base[1..($base.Count - 1)] -m venv (Join-Path $root '.venv')
    if (-not (Test-Path $python)) { Die '虚拟环境创建失败。' }
    $needDeps = $true
}

$probe = & $python -c "import fastapi, uvicorn, sqlalchemy, pydantic; print('ok')" 2>&1
if ($LASTEXITCODE -ne 0 -or ($probe -notmatch 'ok')) { $needDeps = $true }
if ($needDeps) {
    Step '安装后端依赖 backend\requirements.txt（一次性，约 1-3 分钟）'
    $env:PIP_DISABLE_PIP_VERSION_CHECK = '1'
    & $python -m pip install -r (Join-Path $root 'backend\requirements.txt')
    if ($LASTEXITCODE -ne 0) { Die '后端依赖安装失败，请检查网络后重试。' }
}

# ---------- 2. Node（前端） ----------
function Find-Node {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $cands = @(
        (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'),
        (Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-plugin-desktop-primary-runtime\dependencies\node\bin\node.exe')
    )
    foreach ($c in $cands) { if ($c -and (Test-Path $c)) { return $c } }
    return $null
}

$node = Find-Node
$viteEntry = Join-Path $root 'frontend\node_modules\vite\bin\vite.js'
if (-not (Test-Path $viteEntry)) {
    if (-not $node) { Die '前端缺少 node_modules，且本机找不到 node.exe。请安装 Node.js 18+ 后重试。' }
    Step '安装前端依赖（一次性，约 1-3 分钟）'
    $npm = $null
    $npmCmd = Get-Command npm -ErrorAction SilentlyContinue
    if ($npmCmd) { $npm = @('npm') }
    $pnpm = Join-Path (Split-Path (Split-Path $node -Parent) -Parent) 'pnpm\bin\pnpm.mjs'
    Push-Location (Join-Path $root 'frontend')
    try {
        if ($npm) {
            & npm install
        } elseif (Test-Path $pnpm) {
            & $node $pnpm install --reporter=append-only
        } else {
            Die '找不到 npm / pnpm，无法安装前端依赖。'
        }
        if ($LASTEXITCODE -ne 0) { Die '前端依赖安装失败，请检查网络后重试。' }
    } finally { Pop-Location }
    if (-not (Test-Path $viteEntry)) { Die '前端依赖安装后仍找不到 vite，请手动在 frontend 目录执行 npm install。' }
}
if (-not $node) { Die '本机找不到 node.exe，前端无法启动。请安装 Node.js 18+。' }

# ---------- 3. 端口检查 ----------
if (Test-PortBusy $BackendPort) { Die ("端口 " + $BackendPort + " 已被占用，可能后端已在运行；如需重启请先执行 .\stop-campus.ps1") }
if (Test-PortBusy $FrontendPort) { Die ("端口 " + $FrontendPort + " 已被占用，可能前端已在运行；如需重启请先执行 .\stop-campus.ps1") }

# ---------- 4. 启动后端 ----------
Step ("启动后端 FastAPI  http://127.0.0.1:" + $BackendPort)
$env:PYTHONPATH = Join-Path $root 'backend'
$env:PYTHONIOENCODING = 'utf-8'
$env:FRONTEND_ORIGINS = "http://127.0.0.1:$FrontendPort,http://localhost:$FrontendPort"
$backendOut = Join-Path $logDir 'backend.log'
$backendErr = Join-Path $logDir 'backend.err.log'

# 用 cmd 包装启动：把日志重定向写在命令里，避免 Windows PowerShell 5.1
# 在 -RedirectStandardOutput 时因环境变量大小写重复（如同时存在 NO_PROXY / no_proxy）而报错。
# 批处理文件只含 ASCII 字符，路径通过环境变量传入，兼容含中文的安装目录。
$env:CAMPUS_PYTHON = $python
$env:CAMPUS_LOGS = $logDir
$backendCmd = Join-Path $logDir 'run-backend.cmd'
@'
@echo off
"%CAMPUS_PYTHON%" -m uvicorn app.main:app --host 127.0.0.1 --port %1 1> "%CAMPUS_LOGS%\backend.log" 2> "%CAMPUS_LOGS%\backend.err.log"
'@ | Set-Content -Path $backendCmd -Encoding ASCII
$backend = Start-Process -FilePath $env:ComSpec -ArgumentList ('/c "' + $backendCmd + '" ' + $BackendPort) `
    -WorkingDirectory (Join-Path $root 'backend') -WindowStyle Hidden -PassThru

if (-not (Wait-Http ("http://127.0.0.1:" + $BackendPort + "/health") 60)) {
    Warn2 '后端未能就绪，最近日志如下：'
    if (Test-Path $backendErr) { Get-Content $backendErr -Tail 25 }
    Die '后端启动失败，完整日志见 .logs\backend.err.log'
}

# ---------- 5. 启动前端 ----------
Step ("启动前端 Vite   http://127.0.0.1:" + $FrontendPort)
$frontOut = Join-Path $logDir 'frontend.log'
$frontErr = Join-Path $logDir 'frontend.err.log'
$env:CAMPUS_NODE = $node
$frontendCmd = Join-Path $logDir 'run-frontend.cmd'
@'
@echo off
"%CAMPUS_NODE%" "node_modules\vite\bin\vite.js" --host 127.0.0.1 --port %1 --strictPort 1> "%CAMPUS_LOGS%\frontend.log" 2> "%CAMPUS_LOGS%\frontend.err.log"
'@ | Set-Content -Path $frontendCmd -Encoding ASCII
$frontend = Start-Process -FilePath $env:ComSpec -ArgumentList ('/c "' + $frontendCmd + '" ' + $FrontendPort) `
    -WorkingDirectory (Join-Path $root 'frontend') -WindowStyle Hidden -PassThru

if (-not (Wait-Http ("http://127.0.0.1:" + $FrontendPort + "/") 60)) {
    Warn2 '前端未能就绪，最近日志如下：'
    if (Test-Path $frontErr) { Get-Content $frontErr -Tail 25 }
    Die '前端启动失败，完整日志见 .logs\frontend.err.log'
}

# ---------- 6. 记录 PID ----------
@{ backend = $backend.Id; frontend = $frontend.Id } |
    ConvertTo-Json | Set-Content -Path (Join-Path $logDir 'pids.json') -Encoding UTF8

$url = "http://127.0.0.1:$FrontendPort"
Write-Host ''
Write-Host '  ================================================================== ' -ForegroundColor Green
Write-Host ("   前端页面 : " + $url) -ForegroundColor Green
Write-Host ("   后端接口 : http://127.0.0.1:" + $BackendPort) -ForegroundColor Green
Write-Host ("   接口文档 : http://127.0.0.1:" + $BackendPort + "/docs") -ForegroundColor Green
Write-Host '   管理后台 : 用管理员账号登录（默认 admin / 见 backend 首次启动输出） ' -ForegroundColor Green
Write-Host '   停止服务 : .\stop-campus.ps1                                  ' -ForegroundColor Green
Write-Host '  ================================================================== ' -ForegroundColor Green
Write-Host ''

if (-not $NoBrowser) { Start-Process $url }
Write-Host ("[完成] 后端 PID " + $backend.Id + "，前端 PID " + $frontend.Id + "；日志在 .logs\ 目录。") -ForegroundColor Cyan
