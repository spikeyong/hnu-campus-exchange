# Publish the local site through a temporary public https URL (Cloudflare quick tunnel).
# No account needed; the URL is random and changes every time the tunnel restarts.
# Usage:  powershell -ExecutionPolicy Bypass -File .\start-tunnel.ps1
#
# Requires the site itself to be running (start-site.ps1) and tools\cloudflared.exe present.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$logDir = Join-Path $root 'data\logs'
$logFile = Join-Path $logDir 'tunnel.log'
$taskName = 'HaidaCampusTunnel'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

$cloudflared = Join-Path $root 'tools\cloudflared.exe'
if (-not (Test-Path $cloudflared)) {
    throw 'tools\cloudflared.exe is missing. Download cloudflared-windows-amd64.exe into site\tools\.'
}

try {
    $health = (Invoke-WebRequest -Uri 'http://127.0.0.1:8080/health' -UseBasicParsing -TimeoutSec 3).StatusCode
} catch {
    $health = 0
}
if ($health -ne 200) {
    throw 'The site is not running on 127.0.0.1:8080. Run .\start-site.ps1 first.'
}

# Already tunnelled? Reuse it instead of burning a new random address.
$runningTunnel = Get-Process cloudflared -ErrorAction SilentlyContinue
if ($runningTunnel -and (Test-Path $logFile)) {
    $existing = Select-String -Path $logFile -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches -ErrorAction SilentlyContinue
    if ($existing) {
        $currentUrl = ($existing.Matches | Select-Object -Last 1).Value
        Write-Host "Tunnel already running: $currentUrl"
        exit 0
    }
}

# schtasks writes to stderr on "task not found"; keep that from terminating the script.
$savedPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& schtasks /query /tn $taskName 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) { & schtasks /end /tn $taskName 2>&1 | Out-Null }
Remove-Item -Path $logFile -Force -ErrorAction SilentlyContinue

$runner = Join-Path $root 'run-tunnel.cmd'
& schtasks /create /tn $taskName /tr ('"' + $runner + '"') /sc once /st 23:59 /f 2>&1 | Out-Null
$createCode = $LASTEXITCODE
& schtasks /run /tn $taskName 2>&1 | Out-Null
$ErrorActionPreference = $savedPreference
if ($createCode -ne 0) { throw 'Could not register the tunnel scheduled task.' }

$deadline = (Get-Date).AddSeconds(90)
$url = $null
while ((Get-Date) -lt $deadline -and -not $url) {
    Start-Sleep -Milliseconds 1200
    if (Test-Path $logFile) {
        $found = Select-String -Path $logFile -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches -ErrorAction SilentlyContinue
        if ($found) {
            $url = ($found.Matches | Select-Object -Last 1).Value
        }
    }
}

if (-not $url) {
    Write-Host 'No public URL yet. Last lines of the tunnel log:'
    Get-Content -Path $logFile -Tail 25 -ErrorAction SilentlyContinue
    exit 1
}

Write-Host "Public URL: $url"
Write-Host 'It is reachable by anyone with the link. Stop it with .\stop-tunnel.ps1'
Write-Host "Tunnel log: $logFile"
