# Rebuild the SPA into site\dist (production build, consumed by app_entry.py).

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$project = Split-Path $root -Parent
$frontend = Join-Path $project 'frontend'

function Find-Node {
    if ($env:CAMPUS_NODE -and (Test-Path $env:CAMPUS_NODE)) { return $env:CAMPUS_NODE }
    $candidates = @(
        (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
    )
    foreach ($candidate in $candidates) { if (Test-Path $candidate) { return $candidate } }
    $command = Get-Command node -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    throw 'Node.js not found. Install it or set CAMPUS_NODE to node.exe.'
}

if (-not (Test-Path (Join-Path $frontend 'node_modules\vite\bin\vite.js'))) {
    throw "vite is missing under frontend\node_modules. Run 'npm install' in frontend first."
}

$node = Find-Node
Push-Location $frontend
try {
    & $node 'node_modules\vite\bin\vite.js' build --outDir (Join-Path $root 'dist') --emptyOutDir
} finally {
    Pop-Location
}

Write-Host "Built into $(Join-Path $root 'dist')"
