"""站点冒烟验证：首页、静态资源、接口、演示账号登录、交易列表。

只用标准库，输出强制 ASCII 安全，避免 Windows 控制台编码干扰判断。
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:8080"


def call(method: str, path: str, body=None, token: str | None = None):
    data = None
    headers = {"Accept": "application/json"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read()
            try:
                return resp.status, json.loads(raw)
            except json.JSONDecodeError:
                return resp.status, raw[:80]
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            return exc.code, json.loads(raw)
        except json.JSONDecodeError:
            return exc.code, raw[:200]


def ascii_safe(value) -> str:
    return json.dumps(value, ensure_ascii=True)[:600]


def main() -> int:
    failures = []

    status, body = call("GET", "/")
    head_ok = status == 200 and isinstance(body, (bytes, str))
    print(f"GET /                      -> {status}")

    status, _ = call("GET", "/health")
    print(f"GET /health                -> {status}")
    if status != 200:
        failures.append("/health")

    status, body = call("GET", "/api/v1/listings")
    items = body.get("items") if isinstance(body, dict) else None
    count = len(items) if isinstance(items, list) else "?"
    print(f"GET /api/v1/listings       -> {status}, listings={count}")
    if status != 200:
        failures.append("/api/v1/listings")

    status, body = call("GET", "/api/v1/listings/categories")
    cats = body if isinstance(body, list) else []
    print(f"GET .../listings/categories-> {status}, categories={len(cats)}")
    if status != 200 or not cats:
        failures.append("/api/v1/listings/categories")

    phone = "13800000001"
    status, body = call("POST", "/api/v1/auth/sms/send", {"phone": phone, "purpose": "login"})
    code = body.get("debug_code") if isinstance(body, dict) else None
    if status == 429:  # 同一号码 60 秒限流，换演示账号再试
        for fallback in ("13800000002", "13800000003"):
            phone = fallback
            status, body = call("POST", "/api/v1/auth/sms/send", {"phone": phone, "purpose": "login"})
            code = body.get("debug_code") if isinstance(body, dict) else None
            if status == 200:
                break
    print(f"POST /auth/sms/send        -> {status}, phone={phone}, debug_code={'yes' if code else 'no'}")
    if status != 200 or not code:
        failures.append("sms/send")
        print(ascii_safe(body))
        return 1

    status, body = call("POST", "/api/v1/auth/sms/login", {"phone": phone, "sms_code": code})
    token = body.get("access_token") if isinstance(body, dict) else None
    print(f"POST /auth/sms/login       -> {status}, token={'yes' if token else 'no'}")
    if status != 200 or not token:
        failures.append("sms/login")
        print(ascii_safe(body))
        return 1

    status, body = call("GET", "/api/v1/auth/me", token=token)
    name = body.get("name") if isinstance(body, dict) else None
    print(f"GET /auth/me               -> {status}, user={ascii_safe(name)}")
    if status != 200:
        failures.append("/auth/me")

    status, body = call("GET", "/api/v1/transactions", token=token)
    rows = body.get("items") if isinstance(body, dict) else body
    size = len(rows) if isinstance(rows, list) else "?"
    print(f"GET /transactions          -> {status}, rows={size}")

    status, body = call("POST", "/api/v1/auth/login", {"identifier": "admin", "password": "Admin123!"})
    admin_ok = status == 200 and isinstance(body, dict) and body.get("access_token")
    print(f"POST /auth/login (admin)   -> {status}, token={'yes' if admin_ok else 'no'}")

    print("RESULT:", "ALL OK" if not failures else "FAILURES: " + ", ".join(failures))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
