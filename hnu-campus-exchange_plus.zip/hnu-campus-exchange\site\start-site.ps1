# Start the one-process site (FastAPI serving /api/v1 + the built SPA).
# Usage:  powershell -ExecutionPolicy Bypass -File .\start-site.ps1 [-Port 8080] [-Bind 0.0.0.0]
#         or double-click start-site.cmd
#
#   -Bind 0.0.0.0   (default) reachable from other machines on the same network
#   -Bind 127.0.0.1 only this machine
#
# The process is launched through a scheduled task (fallback: WMI), so closing
# the terminal does not stop the site.

param(
    [int]$Port = 8080,
    [string]$Bind = '0.0.0.0'
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$dataDir = Join-Path $root 'data'
$logDir = Join-Path $dataDir 'logs'
$taskName = 'CampusExchangeSite'
New-Item -ItemType Directory -Force -Path $dataDir, $logDir, (Join-Path $root 'tmp') | Out-Null

function Find-Python {
    if ($env:CAMPUS_PYTHON -and (Test-Path $env:CAMPUS_PYTHON)) { return $env:CAMPUS_PYTHON }
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'),
        (Join-Path $env:ProgramFiles 'Python312\python.exe'),
        (Join-Path $env:ProgramFiles 'Python313\python.exe')
    )
    foreach ($candidate in $candidates) { if (Test-Path $candidate) { return $candidate } }
    $command = Get-Command python -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    throw 'Python 3.12+ not found. Install it or set CAMPUS_PYTHON to python.exe.'
}

function Test-Health([int]$target) {
    try {
        return (Invoke-WebRequest -Uri "http://127.0.0.1:$target/health" -UseBasicParsing -TimeoutSec 3).StatusCode -eq 200
    } catch {
        return $false
    }
}

function Wait-Healthy([int]$target, [int]$seconds) {
    $deadline = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 700
        if (Test-Health $target) { return $true }
    }
    return $false
}

function Show-Urls([int]$target, [string]$boundTo) {
    Write-Host 'Site running:'
    Write-Host "  http://127.0.0.1:$target/        (this computer)"
    if ($boundTo -eq '0.0.0.0') {
        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
            ForEach-Object { Write-Host "  http://$($_.IPAddress):$target/        ($($_.InterfaceAlias))" }
        Write-Host 'Other machines must be on the same network / VPN.'
    }
    Write-Host "Log: $(Join-Path $logDir 'site.log')"
}

if (-not (Test-Path (Join-Path $root 'dist\index.html'))) {
    throw 'dist/ is missing. Run .\rebuild-frontend.ps1 first (needs Node.js and frontend/node_modules).'
}

if (Test-Health $Port) {
    Show-Urls $Port $Bind
    exit 0
}

$python = Find-Python
$launch = Join-Path $root 'launch.py'
Set-Content -Path (Join-Path $dataDir 'python.txt') -Value $python -Encoding ASCII

# 1) Scheduled task: survives terminal close and logoff/logon.
$taskCommand = '"' + $python + '" "' + $launch + '" ' + $Port + ' ' + $Bind
$savedPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& schtasks /create /tn $taskName /tr $taskCommand /sc once /st 23:59 /f 2>&1 | Out-Null
$created = $LASTEXITCODE -eq 0
if ($created) { & schtasks /run /tn $taskName 2>&1 | Out-Null }
$ErrorActionPreference = $savedPreference
if ($created -and (Wait-Healthy $Port 45)) {
    Show-Urls $Port $Bind
    exit 0
}

# 2) WMI: detaches from the calling shell's job object.
try {
    $result = Invoke-CimMethod -ClassName Win32_Process -MethodName Create `
        -Arguments @{ CommandLine = $taskCommand } -ErrorAction Stop
    if ($result.ReturnValue -eq 0 -and (Wait-Healthy $Port 45)) {
        Set-Content -Path (Join-Path $dataDir 'site.pid') -Value $result.ProcessId -Encoding ASCII
        Show-Urls $Port $Bind
        exit 0
    }
} catch {
    # fall through to the plain launcher
}

# 3) Plain launcher: works, but dies with the calling shell.
$process = Start-Process -FilePath $python -ArgumentList ('"' + $launch + '" ' + $Port + ' ' + $Bind) -WindowStyle Hidden -PassThru
Set-Content -Path (Join-Path $dataDir 'site.pid') -Value $process.Id -Encoding ASCII
if (Wait-Healthy $Port 30) {
    Write-Host '(started in this shell only - it will stop when this window closes)'
    Show-Urls $Port $Bind
    exit 0
}

Write-Host 'Server did not become ready. Last lines of the log:'
Get-Content -Path (Join-Path $logDir 'site.log') -Tail 25 -ErrorAction SilentlyContinue
exit 1
