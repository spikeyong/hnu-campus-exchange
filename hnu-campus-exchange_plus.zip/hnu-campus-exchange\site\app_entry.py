"""一体化站点入口：用同一个 FastAPI 进程同时提供接口和前端构建产物。

与开发模式（前端 5173 + 后端 8000）的区别：

- 前端产物由本进程挂在 `/`，接口仍在 `/api/v1`，**同源**，不需要 nginx、不需要 CORS、不需要代理；
- 运行时数据（SQLite、上传目录）放在 `site/data/`，不污染仓库；
- 原项目的 `backend/app` 一行不改，只是被导入。

启动方式见 `site/README.md` 或双击 `start-site.cmd`。
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent  # site/ 的上一级就是项目根
DIST = HERE / "dist"
DATA = HERE / "data"
BACKEND = PROJECT / "backend"

DATA.mkdir(parents=True, exist_ok=True)
(DATA / "uploads").mkdir(parents=True, exist_ok=True)

# 关键：SECRET_KEY 必须与已有数据库一致。手机号的 blind_index（HMAC）、
# 认证材料的 AES-GCM 密文都由它派生，换 key 后已有账号会"查不到"。
# 空库首次启动时用它建管理员；之后如需更换，请同时重建数据。
os.environ.setdefault("APP_ENV", "development")
os.environ.setdefault(
    "DATABASE_URL", "sqlite:///" + (DATA / "campus_exchange.db").as_posix()
)
os.environ.setdefault("UPLOAD_DIR", str(DATA / "uploads"))
os.environ.setdefault(
    "FRONTEND_ORIGINS", "http://127.0.0.1:8080,http://localhost:8080"
)
os.environ.setdefault(
    "SECRET_KEY", os.environ.get("CAMPUS_SECRET_KEY") or "development-only-change-me"
)

os.chdir(BACKEND)
sys.path.insert(0, str(BACKEND))

from fastapi import HTTPException  # noqa: E402
from fastapi.responses import FileResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

from app.main import app  # noqa: E402  （原项目的 FastAPI 实例）

_DIST_ROOT = DIST.resolve()
_API_PREFIXES = ("api/", "uploads/")


if (DIST / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="site-assets")


@app.get("/{full_path:path}", include_in_schema=False)
def serve_site(full_path: str):
    """先当静态文件，找不到就回 index.html（前端用 hash 路由，回退只为兜底）。"""
    if full_path.startswith(_API_PREFIXES):
        raise HTTPException(status_code=404, detail="Not Found")

    if full_path:
        candidate = (DIST / full_path).resolve()
        if candidate.is_relative_to(_DIST_ROOT) and candidate.is_file():
            return FileResponse(candidate)

    index = DIST / "index.html"
    if not index.is_file():
        raise HTTPException(
            status_code=503,
            detail="前端尚未构建：请先在 site/ 目录运行 rebuild-frontend.ps1（或 cd frontend && npm run build）",
        )
    return FileResponse(index)
