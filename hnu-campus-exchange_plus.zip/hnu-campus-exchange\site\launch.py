"""Standalone launcher for the site: ``<python> launch.py [port]``.

Resolves sys.path, redirects output to ``data/logs/site.log`` and starts
uvicorn. No environment variables or working directory are required, which
makes it safe to start from a detached process (WMI / Task Scheduler).
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(HERE, "data", "logs")
TMP_DIR = os.path.join(HERE, "tmp")
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(TMP_DIR, exist_ok=True)

sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "lib"))

os.environ.setdefault("TMP", TMP_DIR)
os.environ.setdefault("TEMP", TMP_DIR)
os.environ.setdefault("TMPDIR", TMP_DIR)
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
HOST = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"

_log = open(os.path.join(LOG_DIR, "site.log"), "a", encoding="utf-8", buffering=1)
sys.stdout = _log
sys.stderr = _log
try:  # also catch writes coming from C-level handles
    os.dup2(_log.fileno(), 1)
    os.dup2(_log.fileno(), 2)
except OSError:
    pass

print(f"--- launch.py start pid={os.getpid()} host={HOST} port={PORT} ---", flush=True)

import uvicorn  # noqa: E402

uvicorn.run("app_entry:app", host=HOST, port=PORT, log_level="info")
