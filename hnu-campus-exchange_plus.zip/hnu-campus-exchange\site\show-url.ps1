# Show the site status and every address that currently works.
# Usage:  powershell -ExecutionPolicy Bypass -File .\show-url.ps1

$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
$logFile = Join-Path $root 'data\logs\tunnel.log'

function Test-Health([int]$target) {
    try {
        return (Invoke-WebRequest -Uri "http://127.0.0.1:$target/health" -UseBasicParsing -TimeoutSec 3).StatusCode -eq 200
    } catch {
        return $false
    }
}

$siteUp = Test-Health 8080
Write-Host ('Site   : ' + $(if ($siteUp) { 'running' } else { 'NOT running  ->  run start-site.cmd' }))

if ($siteUp) {
    Write-Host '  http://127.0.0.1:8080/'
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        ForEach-Object { Write-Host "  http://$($_.IPAddress):8080/    ($($_.InterfaceAlias))" }
}

$tunnel = Get-Process cloudflared -ErrorAction SilentlyContinue
Write-Host ('Tunnel : ' + $(if ($tunnel) { 'running' } else { 'NOT running  ->  run start-tunnel.ps1' }))

if (Test-Path $logFile) {
    $found = Select-String -Path $logFile -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches -ErrorAction SilentlyContinue
    if ($found) {
        $url = ($found.Matches | Select-Object -Last 1).Value
        Write-Host "  $url"
        Write-Host '  (this is the newest tunnel address; it changes every time the tunnel restarts)'
    }
}

if (-not $siteUp -and -not $tunnel) {
    Write-Host ''
    Write-Host 'Nothing is running. Double-click start-site.cmd, then start-tunnel.ps1 for a public link.'
}
